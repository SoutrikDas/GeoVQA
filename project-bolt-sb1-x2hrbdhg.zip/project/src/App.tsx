import { useState } from 'react';
import { MapPin } from 'lucide-react';
import ImageUpload from './components/ImageUpload';
import QuestionInput from './components/QuestionInput';
import MapView from './components/MapView';
import AnswerDisplay from './components/AnswerDisplay';
import HistoryPanel from './components/HistoryPanel';

interface Location {
  latitude: number;
  longitude: number;
  name: string;
  confidence: number;
}

interface HistoryItem {
  id: string;
  question: string;
  answer: string;
  timestamp: Date;
  imagePreview: string;
}

function App() {
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');
  const [currentQuestion, setCurrentQuestion] = useState<string>('');
  const [answer, setAnswer] = useState<string>('');
  const [location, setLocation] = useState<Location | undefined>();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string>('');
  const [history, setHistory] = useState<HistoryItem[]>([]);

  const handleImageSelect = (file: File, preview: string) => {
    setImageFile(file);
    setImagePreview(preview);
    setAnswer('');
    setLocation(undefined);
    setError('');
  };

  const handleClearImage = () => {
    setImageFile(null);
    setImagePreview('');
    setAnswer('');
    setLocation(undefined);
    setError('');
    setCurrentQuestion('');
  };

  const handleQuestionSubmit = async (question: string) => {
    if (!imageFile) {
      setError('Please upload an image first');
      return;
    }

    setCurrentQuestion(question);
    setIsLoading(true);
    setError('');

    await new Promise(resolve => setTimeout(resolve, 2000));

    const isGeographical = Math.random() > 0.2;

    if (!isGeographical) {
      setError('This works only with geographical dataset.');
      setIsLoading(false);
      return;
    }

    const mockAnswers = [
      "This image shows the Golden Gate Bridge in San Francisco, California. The distinctive Art Deco suspension bridge spans the Golden Gate strait, connecting San Francisco to Marin County. The image captures the iconic International Orange color of the bridge against the backdrop of the bay waters.",
      "Based on the geographical features visible, this appears to be a mountainous region with snow-capped peaks. The terrain suggests this could be part of the Rocky Mountains or similar alpine environment, characterized by steep elevations and glacial formations.",
      "This coastal area features characteristic Mediterranean geography, with limestone cliffs meeting clear blue waters. The vegetation and geological formations are typical of regions along the Adriatic or Aegean seas.",
      "The image shows an urban landscape with modern skyscrapers and dense development patterns typical of major metropolitan areas in East Asia. The architectural style and city planning suggest this could be a major financial district.",
    ];

    const mockLocations: Location[] = [
      { latitude: 37.8199, longitude: -122.4783, name: "San Francisco, California", confidence: 0.92 },
      { latitude: 39.7392, longitude: -104.9903, name: "Rocky Mountains Region", confidence: 0.85 },
      { latitude: 43.5081, longitude: 16.4402, name: "Split, Croatia", confidence: 0.88 },
      { latitude: 22.3193, longitude: 114.1694, name: "Hong Kong", confidence: 0.91 },
    ];

    const randomIndex = Math.floor(Math.random() * mockAnswers.length);
    const mockAnswer = mockAnswers[randomIndex];
    const mockLocation = mockLocations[randomIndex];

    setAnswer(mockAnswer);
    setLocation(mockLocation);
    setIsLoading(false);

    const newHistoryItem: HistoryItem = {
      id: Date.now().toString(),
      question,
      answer: mockAnswer,
      timestamp: new Date(),
      imagePreview,
    };
    setHistory([newHistoryItem, ...history].slice(0, 10));
  };

  const handleClearHistory = () => {
    setHistory([]);
  };

  const handleSelectHistory = (item: HistoryItem) => {
    setCurrentQuestion(item.question);
    setAnswer(item.answer);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100">
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white py-3 shadow-md">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm font-medium"><b>Indian Institute Of Technology Bhubaneswar</b></p>

        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <header className="mb-8 text-center">
          <div className="flex items-center justify-center gap-3 mb-3">
            <MapPin className="h-10 w-10 text-blue-600" />
            <h1 className="text-4xl font-bold text-gray-900">
              Geo-Visual QA
            </h1>
          </div>
          <p className="text-gray-600 text-lg">
            Upload an image and ask questions about its geographical location and features
          </p>
          <p>Cretaed by:-Sagnik Koyal(25AI06021)</p>
          <p>Arindam Das(25AI06003)</p>
          <p>Soutrik Das(25AI06011)</p>
          <p>Deepta Kiran Das(25AI06005)</p>
          <p>Sayan Dey(25AI06009)</p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Upload Image</h2>
              <ImageUpload
                onImageSelect={handleImageSelect}
                currentImage={imagePreview}
                onClear={handleClearImage}
              />
            </div>

            {imagePreview && (
              <div className="bg-white rounded-lg shadow-lg p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Ask a Question</h2>
                <QuestionInput
                  onSubmit={handleQuestionSubmit}
                  disabled={isLoading}
                />
              </div>
            )}

            {(answer || isLoading || error) && (
              <div className="space-y-4">
                <h2 className="text-xl font-semibold text-gray-900">Results</h2>

                {currentQuestion && !isLoading && (
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <h3 className="font-semibold text-blue-900 mb-2">Question</h3>
                    <p className="text-blue-800">{currentQuestion}</p>
                  </div>
                )}

                <AnswerDisplay
                  answer={answer}
                  isLoading={isLoading}
                  error={error}
                />
              </div>
            )}

            {location && (
              <div>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Detected Location</h2>
                <MapView location={location} />
              </div>
            )}
          </div>

          <div className="lg:col-span-1">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">History</h2>
            <HistoryPanel
              history={history}
              onClear={handleClearHistory}
              onSelect={handleSelectHistory}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
